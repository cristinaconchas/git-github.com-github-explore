This is example project for [Firebase Authentication Tutorial](http://maksimivanov.com/posts/firebase-react-tutorial)

You'll have to create `.env` file with your Firebase app credentials. Read article for the instructions.

This project was bootstrapped with [Create React App](https://github.com/facebookincubator/create-react-app).
